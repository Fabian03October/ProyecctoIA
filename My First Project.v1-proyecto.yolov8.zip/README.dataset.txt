# My First Project > Proyecto
https://universe.roboflow.com/ia-vcwaz/my-first-project-4liye

Provided by a Roboflow user
License: CC BY 4.0

